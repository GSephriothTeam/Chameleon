

#ifndef CEPHES_EIGENS_H
#define CEPHES_EIGENS_H

void cephes_eigens(double *A, double *EV, double *E, int N);

#endif /* CEPHES_EIGENS_H */
