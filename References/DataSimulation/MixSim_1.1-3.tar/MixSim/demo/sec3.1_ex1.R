### Example 1 of Section 3.1
set.seed(1234)
(ex.1 <- MixSim(BarOmega = 0.05, MaxOmega = 0.15, K = 4, p = 5))
summary(ex.1)
