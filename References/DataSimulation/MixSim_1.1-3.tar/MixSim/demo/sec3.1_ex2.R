### Example 2 of Section 3.1
set.seed(1234)
(ex.2 <- MixSim(MaxOmega = 0.1, K = 3, p = 2, sph = TRUE, PiLow = 0.1))
summary(ex.2)
